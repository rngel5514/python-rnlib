from optparse import OptionParser 

def opthandler():
    usage = "usage: %prog <options>"
    parser = OptionParser(usage)
    parser.add_option("-x", "--ip", dest="mip",
                    action="store_true",
                    help="mip is a output standard", default=False)
    (options, args) = parser.parse_args()
    return options,args
options,args = opthandler()
if(len(args) == 1):
    print args
    tem = args[0]
cl = 0
amm = 0
re = 0
amh = 0
readd = dict()
with open(tem,'r') as fr:
    for line in fr.readlines():
        tm=line.split("[Priority: ",1)[1]
        tm=tm.split("]",1)[0]
        line.strip()
        tim =  line.split()
        tim = tim[0]
        timh = tim.split(":",1)[0]
        # tim-h = tim-h[0]
        timm = tim.split(":",2)[1]
        t=line.split("[**]",2)
        t=t[2].split("[Prio",1)[0]
        # tim-m =  tim-m[0]
        if ( not (amh == timh and int(timm) < amm )):
            cl = 1
        if(cl == 1 ): 
            reout = "Clas:"+str(re)+" "+"dif:"+str(readd)+" "
            with open(tem+'.bak','a') as fw:
                fw.write(reout)
            print reout
            readd=dict()
            readd[int(tm)] = 1
            amm = int(timm)+5
            amh = timh
            dif = list()
            dif.append(t)
            re = 1
            cl = 0
            continue
        else:
            if readd.has_key(int(tm)) == 0:
                readd[int(tm)] = 1
            else:
                readd[int(tm)] +=1
            if t not in dif:
                dif.append(t)
                re = re + 1
    reout = "Clas:"+str(re)+" "+"dif:"+str(readd)+" "
    with open(tem+'.bak','a') as fw:
        fw.write(reout)